<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-shield-check {{ $class ?? '' }}" width="{{ $width ?? '24' }}" height="{{ $height ?? '24' }}" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
    <path d="M9 12l2 2l4 -4"></path>
    <path d="M12 3a12 12 0 0 0 8.5 3a12 12 0 0 1 -8.5 15a12 12 0 0 1 -8.5 -15a12 12 0 0 0 8.5 -3"></path>
 </svg>