<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-receipt {{ $class ?? '' }}" width="{{ $width }}" height="{{ $height }}" style="{{ $style ?? '' }}" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
    <path d="M5 21v-16a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v16l-3 -2l-2 2l-2 -2l-2 2l-2 -2l-3 2m4 -14h6m-6 4h6m-2 4h2"></path>
</svg>