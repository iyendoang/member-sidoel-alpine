<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-photo-search {{ $class ?? '' }}" style="{{ $style ?? '' }}" width="{{ $width }}" height="{{ $height }}" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
    <path d="M15 8h.01"></path>
    <path d="M12 20h-5a3 3 0 0 1 -3 -3v-10a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v4.5"></path>
    <path d="M4 15l4 -4c.928 -.893 2.072 -.893 3 0l2 2"></path>
    <path d="M18 18m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0"></path>
    <path d="M20.2 20.2l1.8 1.8"></path>
 </svg>