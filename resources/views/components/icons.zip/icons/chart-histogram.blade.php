<svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-chart-histogram {{ $class ?? '' }}" width="{{ $width }}" height="{{ $height }}" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
    <path d="M3 3v18h18"></path>
    <path d="M20 18v3"></path>
    <path d="M16 16v5"></path>
    <path d="M12 13v8"></path>
    <path d="M8 16v5"></path>
    <path d="M3 11c6 0 5 -5 9 -5s3 5 9 5"></path>
</svg>